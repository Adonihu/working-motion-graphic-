export interface ActMarker {
  id: string;
  name: string;
  subtitle: string;
  timeSec: number;
  frame: number;
  color: string;
}

export interface BrandColor {
  name: string;
  hex: string;
  threeHex: string;
  description: string;
  bgClass: string;
}

export type AspectRatioType = '1:1' | '16:9' | '9:16' | '4:5' | 'free';

export type AlphaPreviewMode = 'studio' | 'checkerboard' | 'matte';

export interface RenderState {
  currentFrame: number;
  totalFrames: number;
  fps: number;
  isPlaying: boolean;
  playbackSpeed: number;
  isLooping: boolean;
  aspectRatio: AspectRatioType;
  alphaMode: AlphaPreviewMode;
  isReady: boolean;
}

export type ExportResolution =
  | '720x720'
  | '800x800'
  | '1080x1080'
  | '1440x1440'
  | '2160x2160'
  | '1920x1080'
  | '3840x2160'
  | '1080x1920'
  | '1080x1350';

export type ExportFormat =
  | 'mov-prores4444' // Apple ProRes 4444 & 4444 XQ (.mov with Alpha)
  | 'mov-qtrle' // QuickTime Animation / qtrle (.mov with Alpha)
  | 'mov-cineform' // GoPro CineForm RGB + Alpha (.mov)
  | 'mov-dnxhr' // Avid DNxHR HQX 444 (.mov with Alpha)
  | 'webm-vp9-alpha' // WebM VP9 Transparent Video (Web / OBS / NLEs)
  | 'webm-vp8-alpha' // WebM VP8 Transparent Video
  | 'avi-huffyuv' // Lossless HuffYUV RGBA (.avi)
  | 'raw-rgba' // Uncompressed Raw 32-bit RGBA (.mov)
  | 'mp4-h264' // Standard H.264 MP4 (Universal)
  | 'png-sequence'; // Lossless 32-bit RGBA PNG Sequence (.zip)

export interface ExportSettings {
  resolution: ExportResolution;
  fps: 24 | 30 | 60;
  format: ExportFormat;
  bitrateMbps: number;
  transparentBackground: boolean; // True Alpha Channel Transparency
  safeMode: boolean; // Low-End PC Memory & CPU Crash Protection
  startFrame: number;
  endFrame: number;
}

