import { ActMarker, BrandColor } from '../types';

export const MANDATORY_BRAND_PALETTE: BrandColor[] = [
  {
    name: 'Deep',
    hex: '#174EA6',
    threeHex: '0x174EA6',
    description: 'Deep midnight blue background, atmospheric depth & stage base',
    bgClass: 'bg-[#174EA6]',
  },
  {
    name: 'Primary',
    hex: '#1A73E8',
    threeHex: '0x1A73E8',
    description: 'Core brand blue, kinetic motion focus & search bar accents',
    bgClass: 'bg-[#1A73E8]',
  },
  {
    name: 'Secondary',
    hex: '#4285F4',
    threeHex: '0x4285F4',
    description: 'Vibrant secondary blue, fluid gradients & active highlights',
    bgClass: 'bg-[#4285F4]',
  },
  {
    name: 'Soft',
    hex: '#8AB4F8',
    threeHex: '0x8AB4F8',
    description: 'Soft luminous blue, ambient backlight & blur glows',
    bgClass: 'bg-[#8AB4F8]',
  },
  {
    name: 'Pale',
    hex: '#D2E3FC',
    threeHex: '0xD2E3FC',
    description: 'Pale ice blue, subtle highlight strokes & editorial text',
    bgClass: 'bg-[#D2E3FC]',
  },
  {
    name: 'Surface',
    hex: '#E8F0FE',
    threeHex: '0xE8F0FE',
    description: 'Clean surface white-blue, typography fill & foreground clarity',
    bgClass: 'bg-[#E8F0FE]',
  },
];

export const ACT_MARKERS: ActMarker[] = [
  {
    id: 'act1',
    name: 'Act 1: Kinetic Morph',
    subtitle: 'Accent line sweeps & morphs into fluid kinetic search circle',
    timeSec: 0.0,
    frame: 0,
    color: '#8AB4F8',
  },
  {
    id: 'act2',
    name: 'Act 2: Search Bar Bounce',
    subtitle: 'Elastic drop into search bar, glow sweep & text typing reveal',
    timeSec: 1.4,
    frame: 84,
    color: '#4285F4',
  },
  {
    id: 'act3',
    name: 'Act 3: 3D Dolly Dive',
    subtitle: 'Camera dive down to Zone 2 with optical shutter blur',
    timeSec: 4.0,
    frame: 240,
    color: '#1A73E8',
  },
  {
    id: 'act4',
    name: 'Act 4: EDITORS are cooked',
    subtitle: 'Gaussian blur text reveal & crying emoji tear cascade',
    timeSec: 4.9,
    frame: 294,
    color: '#E8F0FE',
  },
  {
    id: 'act5',
    name: 'Act 5: Title Dock & 4 Cards',
    subtitle: 'Headline glides to top & 4 uniform cards fade in with blur',
    timeSec: 6.3,
    frame: 378,
    color: '#8AB4F8',
  },
  {
    id: 'act6',
    name: 'Act 6: Morph to 1:1 Frames',
    subtitle: 'Cards morph dynamically into 1:1 square showcase frames',
    timeSec: 7.10,
    frame: 426,
    color: '#4285F4',
  },
  {
    id: 'act7',
    name: 'Act 7: 4-Canva Playback',
    subtitle: 'All 4 animated video canvases play synchronously in loop',
    timeSec: 7.65,
    frame: 459,
    color: '#93C5FD',
  },
  {
    id: 'act8',
    name: 'Act 8: Camera Flight Up',
    subtitle: 'Cards kinetic recoil & rapid upward flight with motion blur',
    timeSec: 9.90,
    frame: 594,
    color: '#60A5FA',
  },
  {
    id: 'act9',
    name: 'Act 9: "comment more"',
    subtitle: 'Editorial typography reveal with morphing glowing underline',
    timeSec: 11.10,
    frame: 666,
    color: '#C2E7FF',
  },
  {
    id: 'act10',
    name: 'Act 10: Cinematic Outro',
    subtitle: 'High-speed camera pullback into deep space until fade',
    timeSec: 12.70,
    frame: 762,
    color: '#E8F0FE',
  },
];

export const RENDER_MJS_SCRIPT = `// 4K 60FPS Headless Renderer: render_4k.mjs
// Supports ProRes 422 HQ, ProRes 4444, H.264 (MP4), H.265 (HEVC), WebM (VP9)
// Usage: node render_4k.mjs [resolution=4k|2k|1080p] [fps=60|30] [codec=prores|h264|hevc|webm]

import puppeteer from 'puppeteer';
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

// Configurable render parameters
const RESOLUTION = process.argv[2] || '4k'; // '4k' (2160x2160), '2k' (1440x1440), '1080p' (1080x1080)
const FPS = parseInt(process.argv[3] || '60', 10);
const CODEC = process.argv[4] || 'h264'; // 'prores' | 'h264' | 'hevc' | 'webm'

const RES_MAP = {
  '4k': { width: 2160, height: 2160, scale: 2.7 },
  '2k': { width: 1440, height: 1440, scale: 1.8 },
  '1080p': { width: 1080, height: 1080, scale: 1.35 },
  '800p': { width: 800, height: 800, scale: 1.0 },
};

const targetRes = RES_MAP[RESOLUTION] || RES_MAP['4k'];

async function render() {
  console.log(\`🎬 Starting Studio Render: \${targetRes.width}x\${targetRes.height} @ \${FPS} FPS (\${CODEC.toUpperCase()})\`);

  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--enable-webgl',
      '--enable-accelerated-2d-canvas',
      '--disable-gpu-vsync',
      '--window-size=2400,2400'
    ]
  });

  const page = await browser.newPage();
  await page.setViewport({
    width: targetRes.width,
    height: targetRes.height,
    deviceScaleFactor: 1
  });

  const fileUrl = 'file://' + path.resolve('./canvas.html');
  await page.goto(fileUrl, { waitUntil: 'networkidle0' });

  // Wait for harness synchronization
  await page.waitForFunction(() => window.READY === true);
  const totalFrames = await page.evaluate(() => window.TOTAL_FRAMES || 840);

  fs.mkdirSync('./frames_4k', { recursive: true });

  console.log(\`📸 Capturing \${totalFrames} high-fidelity frames deterministically...\`);
  for (let f = 0; f < totalFrames; f++) {
    await page.evaluate((frame) => window.seekFrame(frame), f);
    const padded = String(f).padStart(5, '0');
    await page.screenshot({
      path: \`./frames_4k/frame_\${padded}.png\`,
      omitBackground: false
    });

    if (f % 30 === 0 || f === totalFrames - 1) {
      const pct = Math.round(((f + 1) / totalFrames) * 100);
      console.log(\`[Progress: \${pct}%] Frame \${f + 1} / \${totalFrames}\`);
    }
  }

  await browser.close();

  console.log(\`🎞️ Encoding \${CODEC.toUpperCase()} video stream via FFmpeg...\`);
  let ffmpegCmd = '';
  
  if (CODEC === 'prores') {
    // Apple ProRes 422 HQ Master
    ffmpegCmd = \`ffmpeg -y -r \${FPS} -i ./frames_4k/frame_%05d.png -c:v prores_ks -profile:v 3 -pix_fmt yuv422p10le output_4k_prores.mov\`;
  } else if (CODEC === 'hevc') {
    // H.265 HEVC 10-bit Master
    ffmpegCmd = \`ffmpeg -y -r \${FPS} -i ./frames_4k/frame_%05d.png -c:v libx265 -crf 14 -pix_fmt yuv420p10le -preset slow output_4k_hevc.mp4\`;
  } else if (CODEC === 'webm') {
    // Google WebM VP9 4K
    ffmpegCmd = \`ffmpeg -y -r \${FPS} -i ./frames_4k/frame_%05d.png -c:v libvpx-vp9 -b:v 35M -crf 15 -pix_fmt yuv420p output_4k.webm\`;
  } else {
    // Master H.264 MP4 (Universally compatible)
    ffmpegCmd = \`ffmpeg -y -r \${FPS} -i ./frames_4k/frame_%05d.png -c:v libx264 -pix_fmt yuv420p -preset slow -crf 16 output_4k.mp4\`;
  }

  execSync(ffmpegCmd, { stdio: 'inherit' });
  console.log('✅ Render complete! Master video output generated.');
}

render().catch(console.error);
`;
