import React, { useState, useRef, useEffect } from 'react';
import { RENDER_MJS_SCRIPT, ACT_MARKERS } from '../data/sceneConstants';
import { RenderState, ExportResolution, ExportFormat, ExportSettings } from '../types';
import {
  Copy,
  Check,
  Download,
  Video,
  Terminal,
  Play,
  Loader2,
  Sparkles,
  ShieldCheck,
  Film,
  Archive,
  FileCheck,
  Camera,
  Sliders,
  Layers,
  Cpu,
  Tv,
} from 'lucide-react';

interface ExportPanelProps {
  renderState: RenderState;
  onRecordDeterministicExport: (
    settings: ExportSettings,
    onProgress: (pct: number, frame: number, estSecRemaining: number) => void,
    signal?: { cancelled: boolean }
  ) => Promise<Blob | null>;
  onExportZipSequence: (
    settings: ExportSettings,
    onProgress: (pct: number, frame: number, estSecRemaining: number) => void,
    signal?: { cancelled: boolean }
  ) => Promise<Blob | null>;
  onCaptureSnapshot: (resolution: ExportResolution, transparent?: boolean) => void;
}

interface CodecInfo {
  id: ExportFormat;
  label: string;
  container: string;
  alphaSupported: boolean;
  category: 'pro' | 'web' | 'lossless';
  description: string;
  ffmpegFlag: string;
}

const CODEC_OPTIONS: CodecInfo[] = [
  {
    id: 'mov-prores4444',
    label: 'Apple ProRes 4444 & 4444 XQ (.mov)',
    container: 'mov',
    alphaSupported: true,
    category: 'pro',
    description: 'Gold standard for After Effects, DaVinci Resolve & Premiere Pro. Up to 16-bit Alpha channel.',
    ffmpegFlag: '-c:v prores_ks -profile:v 4 -pix_fmt yuva444p10le',
  },
  {
    id: 'mov-qtrle',
    label: 'QuickTime Animation / qtrle (.mov)',
    container: 'mov',
    alphaSupported: true,
    category: 'pro',
    description: 'Lossless run-length encoded 8-bit Alpha animation. Universal NLE & Apple QuickTime playback.',
    ffmpegFlag: '-c:v qtrle -pix_fmt argb',
  },
  {
    id: 'mov-cineform',
    label: 'GoPro CineForm RGB + Alpha (.mov)',
    container: 'mov',
    alphaSupported: true,
    category: 'pro',
    description: '12-bit high dynamic range intermediate codec with alpha for Windows & Mac VFX pipelines.',
    ffmpegFlag: '-c:v cfhd -pix_fmt yuv444p10le',
  },
  {
    id: 'mov-dnxhr',
    label: 'Avid DNxHR HQX / 444 (.mov)',
    container: 'mov',
    alphaSupported: true,
    category: 'pro',
    description: 'High-bitrate Avid broadcast standard with precision alpha transparency support.',
    ffmpegFlag: '-c:v dnxhd -profile:v dnxhr_444 -pix_fmt yuv444p10le',
  },
  {
    id: 'webm-vp9-alpha',
    label: 'WebM VP9 Transparent Alpha (.webm)',
    container: 'webm',
    alphaSupported: true,
    category: 'web',
    description: 'Transparent video natively playable in browsers, OBS Studio, and video editors.',
    ffmpegFlag: '-c:v libvpx-vp9 -pix_fmt yuva420p -b:v 25M',
  },
  {
    id: 'webm-vp8-alpha',
    label: 'WebM VP8 Transparent Alpha (.webm)',
    container: 'webm',
    alphaSupported: true,
    category: 'web',
    description: 'Legacy transparent WebM format with wide hardware playback support.',
    ffmpegFlag: '-c:v libvpx -pix_fmt yuva420p -b:v 20M',
  },
  {
    id: 'avi-huffyuv',
    label: 'Lossless HuffYUV RGBA (.avi)',
    container: 'avi',
    alphaSupported: true,
    category: 'lossless',
    description: 'Blazing fast lossless RGBA compression in AVI container for archival & processing.',
    ffmpegFlag: '-c:v huffyuv -pix_fmt bgra',
  },
  {
    id: 'raw-rgba',
    label: 'Uncompressed 32-bit Raw RGBA (.mov)',
    container: 'mov',
    alphaSupported: true,
    category: 'lossless',
    description: 'Pure pixel-by-pixel uncompressed RGBA frames with direct alpha channel.',
    ffmpegFlag: '-c:v rawvideo -pix_fmt rgba',
  },
  {
    id: 'mp4-h264',
    label: 'Universal Standard MP4 (H.264)',
    container: 'mp4',
    alphaSupported: false,
    category: 'web',
    description: 'Universal compatibility for YouTube, Instagram, mobile devices, and standard web players.',
    ffmpegFlag: '-c:v libx264 -pix_fmt yuv420p -crf 16 -preset slow',
  },
  {
    id: 'png-sequence',
    label: 'Lossless 32-bit PNG Sequence (.zip)',
    container: 'zip',
    alphaSupported: true,
    category: 'lossless',
    description: 'Frame-by-frame 32-bit RGBA PNG image sequence. 100% lossless master archive.',
    ffmpegFlag: '-c:v png',
  },
];

export const ExportPanel: React.FC<ExportPanelProps> = ({
  renderState,
  onRecordDeterministicExport,
  onExportZipSequence,
  onCaptureSnapshot,
}) => {
  const [resolution, setResolution] = useState<ExportResolution>('720x720');
  const [fps, setFps] = useState<24 | 30 | 60>(60);
  const [format, setFormat] = useState<ExportFormat>('mov-prores4444');
  const [transparentBackground, setTransparentBackground] = useState<boolean>(false);
  const [bitrateMbps, setBitrateMbps] = useState<number>(25);
  const [safeMode, setSafeMode] = useState<boolean>(true);
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedFfmpeg, setCopiedFfmpeg] = useState(false);

  // Custom Start & End Frame Range
  const [startFrame, setStartFrame] = useState<number>(0);
  const [endFrame, setEndFrame] = useState<number>(renderState.totalFrames - 1);

  const [isRecording, setIsRecording] = useState(false);
  const [recordProgress, setRecordProgress] = useState(0);
  const [currentRenderFrame, setCurrentRenderFrame] = useState(0);
  const [estSec, setEstSec] = useState(0);
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadFileName, setDownloadFileName] = useState<string>('');
  const [downloadSize, setDownloadSize] = useState<string | null>(null);
  const cancelSignalRef = useRef<{ cancelled: boolean }>({ cancelled: false });

  // Keep endFrame synchronized when totalFrames updates
  useEffect(() => {
    if (renderState.totalFrames > 0 && endFrame >= renderState.totalFrames) {
      setEndFrame(renderState.totalFrames - 1);
    }
  }, [renderState.totalFrames]);

  // Update bitrate recommendation based on resolution
  useEffect(() => {
    if (resolution === '3840x2160' || resolution === '2160x2160') {
      setBitrateMbps(fps === 60 ? 45 : 30);
    } else if (resolution === '1440x1440') {
      setBitrateMbps(28);
    } else if (resolution === '1080x1080' || resolution === '1920x1080') {
      setBitrateMbps(20);
    } else {
      setBitrateMbps(12);
    }
  }, [resolution, fps]);

  const selectedCodecInfo = CODEC_OPTIONS.find((c) => c.id === format) || CODEC_OPTIONS[0];

  const handleCopyScript = () => {
    navigator.clipboard.writeText(RENDER_MJS_SCRIPT);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const getFfmpegCommand = () => {
    const ext = selectedCodecInfo.container;
    const alphaTag = transparentBackground ? '_alpha' : '_studio';
    const outName = `output_${resolution}_${fps}fps${alphaTag}.${ext}`;
    return `ffmpeg -y -framerate ${fps} -i frame_%05d.png ${selectedCodecInfo.ffmpegFlag} ${outName}`;
  };

  const handleCopyFfmpeg = () => {
    navigator.clipboard.writeText(getFfmpegCommand());
    setCopiedFfmpeg(true);
    setTimeout(() => setCopiedFfmpeg(false), 2000);
  };

  const handleSetFullRange = () => {
    setStartFrame(0);
    setEndFrame(renderState.totalFrames - 1);
  };

  const handleSetActRange = (actIndex: number) => {
    const act = ACT_MARKERS[actIndex];
    if (!act) return;
    const nextAct = ACT_MARKERS[actIndex + 1];
    const s = act.frame;
    const e = nextAct ? nextAct.frame - 1 : renderState.totalFrames - 1;
    setStartFrame(s);
    setEndFrame(e);
  };

  const handleStartExport = async () => {
    if (isRecording) return;
    setIsRecording(true);
    setRecordProgress(0);
    setCurrentRenderFrame(0);
    setEstSec(0);
    setDownloadUrl(null);
    setDownloadSize(null);
    cancelSignalRef.current = { cancelled: false };

    const validStart = Math.max(0, Math.min(startFrame, renderState.totalFrames - 1));
    const validEnd = Math.max(validStart, Math.min(endFrame, renderState.totalFrames - 1));

    const settings: ExportSettings = {
      resolution,
      fps,
      format,
      bitrateMbps,
      transparentBackground,
      safeMode,
      startFrame: validStart,
      endFrame: validEnd,
    };

    try {
      let blob: Blob | null = null;

      if (format === 'png-sequence') {
        blob = await onExportZipSequence(
          settings,
          (pct, frame, remaining) => {
            setRecordProgress(pct);
            setCurrentRenderFrame(frame);
            setEstSec(remaining);
          },
          cancelSignalRef.current
        );
        if (blob && !cancelSignalRef.current.cancelled) {
          const url = URL.createObjectURL(blob);
          setDownloadUrl(url);
          const alphaLabel = transparentBackground ? '_transparent' : '';
          const fname = `motion_png_${resolution}_f${validStart}-f${validEnd}_${fps}fps${alphaLabel}.zip`;
          setDownloadFileName(fname);
          const sizeMb = (blob.size / (1024 * 1024)).toFixed(1);
          setDownloadSize(`${sizeMb} MB`);
        }
      } else {
        blob = await onRecordDeterministicExport(
          settings,
          (pct, frame, remaining) => {
            setRecordProgress(pct);
            setCurrentRenderFrame(frame);
            setEstSec(remaining);
          },
          cancelSignalRef.current
        );

        if (blob && !cancelSignalRef.current.cancelled) {
          const url = URL.createObjectURL(blob);
          setDownloadUrl(url);
          const ext = selectedCodecInfo.container;
          const alphaLabel = transparentBackground ? '_transparent' : '';
          const fname = `motion_master_${resolution}_f${validStart}-f${validEnd}_${fps}fps${alphaLabel}.${ext}`;
          setDownloadFileName(fname);
          const sizeMb = (blob.size / (1024 * 1024)).toFixed(1);
          setDownloadSize(`${sizeMb} MB`);
        }
      }
    } catch (err) {
      console.error('Export error:', err);
    } finally {
      setIsRecording(false);
    }
  };

  const handleCancel = () => {
    cancelSignalRef.current.cancelled = true;
    setIsRecording(false);
  };

  const totalFramesToExport = Math.max(1, endFrame - startFrame + 1);
  const durationSec = (totalFramesToExport / fps).toFixed(2);

  return (
    <div
      id="apple-export-studio"
      className="bg-[#121216]/85 backdrop-blur-2xl border border-white/[0.08] rounded-2xl p-5 sm:p-7 shadow-[0_8px_32px_rgba(0,0,0,0.5)] space-y-6"
    >
      {/* Header with Apple Minimalist Style */}
      <div id="export-header-row" className="flex flex-wrap items-center justify-between gap-4 border-b border-white/[0.06] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#1A73E8]/20 border border-[#1A73E8]/40 flex items-center justify-center text-[#8AB4F8]">
              <Film className="w-3.5 h-3.5" />
            </div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Master Video & Transparent Codec Export Studio
            </h2>
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Alpha Transparency Supported</span>
            </span>
          </div>
          <p className="text-xs text-white/50 mt-1">
            Frame-accurate master render with direct browser downloads for Apple ProRes 4444 (.mov), QuickTime Animation (qtrle), WebM VP9 Alpha, and Lossless PNG Sequence.
          </p>
        </div>

        {/* Low-End PC Safe Mode & Memory Guard */}
        <div className="flex items-center gap-2">
          <button
            id="btn-toggle-safe-mode"
            onClick={() => setSafeMode(!safeMode)}
            className={`px-3 py-1.5 rounded-xl text-xs font-medium flex items-center gap-2 transition-all cursor-pointer border ${
              safeMode
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300 shadow-[0_0_12px_rgba(52,211,153,0.15)]'
                : 'bg-white/[0.04] border-white/[0.08] text-white/50 hover:text-white'
            }`}
            title="Safe Mode throttles CPU and frees RAM between frames to guarantee smooth export without browser tab crashes on low-end hardware"
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>Low-End PC Protection: {safeMode ? 'ACTIVE' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* Codec Preset Selector Pills */}
      <div className="space-y-2">
        <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block font-mono">
          Select Video Codec / Export Format
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
          {CODEC_OPTIONS.map((codec) => {
            const isSelected = format === codec.id;
            return (
              <button
                key={codec.id}
                id={`btn-codec-${codec.id}`}
                onClick={() => {
                  setFormat(codec.id);
                  if (codec.alphaSupported && !codec.id.includes('mp4')) {
                    // keep current transparency setting
                  }
                }}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-blue-600/20 border-blue-500/60 shadow-[0_0_16px_rgba(37,99,235,0.2)]'
                    : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.05] hover:border-white/[0.12]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-white truncate">{codec.label}</span>
                  {codec.alphaSupported ? (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono uppercase font-bold shrink-0">
                      Alpha
                    </span>
                  ) : (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/[0.08] text-white/50 font-mono shrink-0">
                      Standard
                    </span>
                  )}
                </div>
                <p className="text-[10.5px] text-white/50 leading-snug line-clamp-2">
                  {codec.description}
                </p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Primary Configuration Grid */}
      <div id="export-settings-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Resolution Selector */}
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3.5 space-y-2">
          <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block font-mono">
            Target Resolution
          </label>
          <select
            id="select-export-resolution"
            value={resolution}
            onChange={(e) => setResolution(e.target.value as ExportResolution)}
            className="w-full bg-[#1A1A1E] text-white text-xs font-medium rounded-lg px-2.5 py-2 border border-white/[0.1] focus:outline-none focus:border-[#1A73E8] cursor-pointer"
          >
            <option value="720x720">720 × 720 (Native 1:1 Square)</option>
            <option value="1080x1080">1080p Full HD Square (1080 × 1080)</option>
            <option value="1440x1440">2K QHD Square (1440 × 1440)</option>
            <option value="2160x2160">4K Ultra Square (2160 × 2160) • Master</option>
            <option value="1920x1080">1080p 16:9 Landscape (1920 × 1080)</option>
            <option value="3840x2160">4K UHD 16:9 Landscape (3840 × 2160)</option>
            <option value="1080x1920">1080p 9:16 Vertical (Reels / TikTok / Shorts)</option>
            <option value="1080x1350">1080p 4:5 Portrait (Instagram Feed)</option>
          </select>
          <p className="text-[10px] text-white/40 leading-tight">
            Adapts HTML elements and graphics dynamically to the selected resolution.
          </p>
        </div>

        {/* 2. Framerate (FPS) */}
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3.5 space-y-2">
          <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block font-mono">
            Framerate (FPS)
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {[24, 30, 60].map((f) => (
              <button
                key={f}
                id={`btn-fps-${f}`}
                onClick={() => setFps(f as 24 | 30 | 60)}
                className={`py-1.5 rounded-lg text-xs font-mono font-medium transition-all cursor-pointer border ${
                  fps === f
                    ? 'bg-[#1A73E8] text-white border-[#4285F4]/60 shadow-md font-semibold'
                    : 'bg-[#1A1A1E] text-white/60 border-white/[0.08] hover:text-white'
                }`}
              >
                {f} FPS
              </button>
            ))}
          </div>
          <p className="text-[10px] text-white/40 leading-tight">
            {fps === 60 ? '60.00 FPS: Exact timeline framerate.' : '30/24 FPS: Standard editing rate.'}
          </p>
        </div>

        {/* 3. Alpha Transparency Toggle */}
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3.5 space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block font-mono">
              Transparency (Alpha)
            </label>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                transparentBackground
                  ? 'bg-emerald-500/20 text-emerald-300'
                  : 'bg-white/[0.08] text-white/50'
              }`}
            >
              {transparentBackground ? 'ALPHA: ON' : 'STUDIO BG'}
            </span>
          </div>
          <button
            id="btn-toggle-transparency"
            onClick={() => setTransparentBackground(!transparentBackground)}
            className={`w-full py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-2 transition-all cursor-pointer ${
              transparentBackground
                ? 'bg-emerald-600/30 border-emerald-500/60 text-emerald-200 shadow-[0_0_12px_rgba(52,211,153,0.2)]'
                : 'bg-[#1A1A1E] border-white/[0.1] text-white/60 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>{transparentBackground ? 'Transparent Background' : 'Include Studio Stage Backdrop'}</span>
          </button>
          <p className="text-[10px] text-white/40 leading-tight">
            {transparentBackground
              ? 'Renders 32-bit RGBA frames with transparent negative space for overlaying onto other videos.'
              : 'Includes deep midnight blue cinematic gradient and spotlight stage.'}
          </p>
        </div>

        {/* 4. Bitrate & Quality */}
        <div className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3.5 space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-[11px] font-semibold text-white/50 uppercase tracking-wider block font-mono">
              Quality Target
            </label>
            <span className="text-xs font-mono text-[#8AB4F8] font-bold">
              {format === 'png-sequence' || format === 'avi-huffyuv' || format === 'raw-rgba'
                ? '100% Lossless'
                : `${bitrateMbps} Mbps`}
            </span>
          </div>
          {format === 'png-sequence' || format === 'avi-huffyuv' || format === 'raw-rgba' ? (
            <div className="py-2 text-[11px] text-emerald-400 font-medium font-mono">
              Lossless 32-bit RGBA Master
            </div>
          ) : (
            <input
              type="range"
              min={6}
              max={60}
              step={2}
              value={bitrateMbps}
              onChange={(e) => setBitrateMbps(parseInt(e.target.value, 10))}
              className="w-full h-1.5 bg-white/[0.1] rounded-full appearance-none cursor-pointer accent-[#1A73E8]"
            />
          )}
          <p className="text-[10px] text-white/40 leading-tight">
            Preserves crisp vector typography and fluid gradient lighting without banding.
          </p>
        </div>
      </div>

      {/* Frame Range Selector (Start Frame to End Frame) */}
      <div className="bg-white/[0.03] border border-white/[0.08] rounded-xl p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-2.5">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#8AB4F8]" />
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white">
              Frame Range & Recording Scope
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSetFullRange}
              className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-[11px] text-white/70 hover:text-white border border-white/[0.08] transition-all cursor-pointer"
            >
              Full Animation (0 → {renderState.totalFrames - 1})
            </button>
            <button
              onClick={() => setStartFrame(renderState.currentFrame)}
              className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-[11px] text-[#8AB4F8] border border-[#8AB4F8]/30 transition-all cursor-pointer"
              title="Set Start Frame to Current Playhead"
            >
              Set Start = Current ({renderState.currentFrame})
            </button>
            <button
              onClick={() => setEndFrame(renderState.currentFrame)}
              className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-[11px] text-[#8AB4F8] border border-[#8AB4F8]/30 transition-all cursor-pointer"
              title="Set End Frame to Current Playhead"
            >
              Set End = Current ({renderState.currentFrame})
            </button>
          </div>
        </div>

        {/* Start Frame & End Frame Input Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-mono text-white/60">
                Start Frame: <strong className="text-white">{startFrame}</strong> ({((startFrame) / fps).toFixed(2)}s)
              </label>
              <input
                type="number"
                min={0}
                max={endFrame}
                value={startFrame}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val)) setStartFrame(Math.max(0, Math.min(val, endFrame)));
                }}
                className="w-20 bg-[#1A1A1E] text-white text-xs font-mono rounded px-2 py-1 border border-white/[0.1] text-right"
              />
            </div>
            <input
              type="range"
              min={0}
              max={renderState.totalFrames - 1}
              value={startFrame}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setStartFrame(Math.min(val, endFrame));
              }}
              className="w-full h-1.5 bg-white/[0.1] rounded-full appearance-none cursor-pointer accent-[#1A73E8]"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between items-center">
              <label className="text-[11px] font-mono text-white/60">
                End Frame: <strong className="text-white">{endFrame}</strong> ({((endFrame) / fps).toFixed(2)}s)
              </label>
              <input
                type="number"
                min={startFrame}
                max={renderState.totalFrames - 1}
                value={endFrame}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10);
                  if (!isNaN(val)) setEndFrame(Math.max(startFrame, Math.min(val, renderState.totalFrames - 1)));
                }}
                className="w-20 bg-[#1A1A1E] text-white text-xs font-mono rounded px-2 py-1 border border-white/[0.1] text-right"
              />
            </div>
            <input
              type="range"
              min={0}
              max={renderState.totalFrames - 1}
              value={endFrame}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setEndFrame(Math.max(val, startFrame));
              }}
              className="w-full h-1.5 bg-white/[0.1] rounded-full appearance-none cursor-pointer accent-[#1A73E8]"
            />
          </div>
        </div>

        {/* Quick Act Presets */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1">
          <span className="text-[10px] text-white/40 uppercase font-mono mr-1">Act Clips:</span>
          {ACT_MARKERS.map((act, idx) => (
            <button
              key={act.id}
              onClick={() => handleSetActRange(idx)}
              className="px-2 py-0.5 rounded text-[10px] font-mono bg-white/[0.04] hover:bg-white/[0.08] text-white/70 hover:text-white border border-white/[0.06] transition-all cursor-pointer"
              title={`Clip ${act.name}`}
            >
              {act.name.split(':')[0]}
            </button>
          ))}
        </div>
      </div>

      {/* Export Action Card */}
      <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#1A73E8]" />
              <span>Export {selectedCodecInfo.label}</span>
            </h3>
            <p className="text-xs text-white/50 mt-0.5">
              Target: <span className="text-white font-mono">{resolution}</span> @{' '}
              <span className="text-white font-mono">{fps} FPS</span> • Frames{' '}
              <span className="text-[#8AB4F8] font-mono font-bold">{startFrame}</span> →{' '}
              <span className="text-[#8AB4F8] font-mono font-bold">{endFrame}</span> ({totalFramesToExport} Frames / ~{durationSec}s)
              {transparentBackground && (
                <span className="ml-2 text-emerald-400 font-mono font-bold">• 32-bit Transparent</span>
              )}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="btn-snapshot-res"
              onClick={() => onCaptureSnapshot(resolution, transparentBackground)}
              className="px-3 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] text-white/80 hover:text-white border border-white/[0.08] text-xs font-medium transition-all flex items-center gap-1.5 cursor-pointer"
              title="Download high-resolution single frame snapshot"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Snapshot Frame {renderState.currentFrame} ({resolution})</span>
            </button>
          </div>
        </div>

        {/* Recording Progress / Controls */}
        {isRecording ? (
          <div className="space-y-3 bg-[#0A0A0C] border border-white/[0.08] rounded-xl p-4">
            <div className="flex flex-wrap justify-between items-center text-xs font-mono gap-2">
              <span className="text-[#8AB4F8] flex items-center gap-2">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-[#1A73E8]" />
                Rendering {selectedCodecInfo.label} • Frame {currentRenderFrame} of {endFrame}...
              </span>
              <div className="flex items-center gap-3">
                {estSec > 0 && <span className="text-white/40">~{estSec}s remaining</span>}
                <span className="text-white font-bold text-sm">{recordProgress}%</span>
              </div>
            </div>

            <div className="w-full bg-white/[0.06] h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#1A73E8] via-[#4285F4] to-[#8AB4F8] h-full rounded-full transition-all duration-150"
                style={{ width: `${recordProgress}%` }}
              />
            </div>

            <div className="flex justify-end pt-1">
              <button
                onClick={handleCancel}
                className="px-3 py-1 text-xs rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 transition-all cursor-pointer"
              >
                Cancel Export
              </button>
            </div>
          </div>
        ) : downloadUrl ? (
          <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <FileCheck className="w-4 h-4" />
              </div>
              <div>
                <p className="text-xs font-semibold text-white">
                  {selectedCodecInfo.label} Master Ready!
                </p>
                <p className="text-[11px] text-white/50">
                  {resolution} • {fps} FPS • Frames {startFrame}–{endFrame} • {downloadSize || 'Ready'}
                  {transparentBackground ? ' • Transparent Alpha' : ''}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <a
                id="btn-download-master-file"
                href={downloadUrl}
                download={downloadFileName}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold py-2 px-4 rounded-xl flex items-center gap-2 transition-all shadow-md cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Download {downloadFileName}
              </a>
              <button
                onClick={handleStartExport}
                className="bg-white/[0.06] hover:bg-white/[0.1] text-white text-xs font-medium py-2 px-3 rounded-xl border border-white/[0.08] transition-all cursor-pointer"
              >
                Render Again
              </button>
            </div>
          </div>
        ) : (
          <button
            id="btn-start-master-export"
            onClick={handleStartExport}
            className="w-full bg-[#1A73E8] hover:bg-[#1A73E8]/90 text-white text-xs font-semibold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(26,115,232,0.35)] cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>
              Start Export: {selectedCodecInfo.label} ({resolution} • Frames {startFrame} → {endFrame} @ {fps}fps)
            </span>
          </button>
        )}
      </div>

      {/* Companion FFmpeg Terminal Command for Post-Production / Studio Integration */}
      <div className="bg-white/[0.02] border border-white/[0.08] rounded-xl p-4 sm:p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-white/50" />
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white/80 font-mono">
              Studio FFmpeg Command: {selectedCodecInfo.label}
            </h4>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="btn-copy-ffmpeg-cmd"
              onClick={handleCopyFfmpeg}
              className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white border border-white/[0.08] text-[11px] flex items-center gap-1.5 transition-all cursor-pointer font-mono"
            >
              {copiedFfmpeg ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedFfmpeg ? 'Copied Command' : 'Copy FFmpeg Command'}</span>
            </button>
            <button
              id="btn-copy-cli-script"
              onClick={handleCopyScript}
              className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-white/70 hover:text-white border border-white/[0.08] text-[11px] flex items-center gap-1.5 transition-all cursor-pointer font-mono"
            >
              {copiedScript ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedScript ? 'Copied Script' : 'Copy render_4k.mjs'}</span>
            </button>
          </div>
        </div>

        <p className="text-xs text-white/50 leading-relaxed">
          Convert exported PNG frames directly into <strong className="text-white">{selectedCodecInfo.label}</strong> with {transparentBackground ? 'full 32-bit Alpha transparency' : 'standard color space'} in your local terminal:
        </p>

        <div className="bg-[#0A0A0C] border border-white/[0.06] rounded-lg p-3 font-mono text-[11px] text-emerald-300 overflow-x-auto select-all">
          <code>{getFfmpegCommand()}</code>
        </div>
      </div>
    </div>
  );
};
