import React, { useState } from 'react';
import { MANDATORY_BRAND_PALETTE } from '../data/sceneConstants';
import { Copy, Check, Sparkles } from 'lucide-react';

export const BrandPaletteViewer: React.FC = () => {
  const [copiedHex, setCopiedHex] = useState<string | null>(null);

  const handleCopy = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedHex(hex);
    setTimeout(() => setCopiedHex(null), 2000);
  };

  return (
    <div
      id="apple-brand-palette-card"
      className="bg-[#121216]/80 backdrop-blur-2xl border border-white/[0.08] rounded-2xl p-5 sm:p-7 shadow-[0_8px_32px_rgba(0,0,0,0.5)] space-y-5"
    >
      <div id="brand-palette-header" className="flex items-center justify-between border-b border-white/[0.06] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-[#1A73E8]/20 border border-[#1A73E8]/40 flex items-center justify-center text-[#8AB4F8]">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <h2 className="text-sm font-semibold text-white tracking-wide">
              Brand Color System
            </h2>
          </div>
          <p className="text-xs text-white/50 mt-1">
            Official hex color standards used throughout the 1:1 motion animation.
          </p>
        </div>
        <span
          id="active-colors-badge"
          className="text-xs px-3 py-1 rounded-full bg-white/[0.04] border border-white/[0.08] text-white/70 font-mono"
        >
          6 Active Tones
        </span>
      </div>

      <div id="color-swatches-grid" className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {MANDATORY_BRAND_PALETTE.map((c) => {
          const isCopied = copiedHex === c.hex;
          return (
            <button
              key={c.name}
              id={`color-swatch-${c.name.toLowerCase()}`}
              onClick={() => handleCopy(c.hex)}
              className="group text-left p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.06] hover:border-white/[0.15] transition-all cursor-pointer relative shadow-sm"
              title={`Click to copy ${c.hex}`}
            >
              <div
                className="w-full h-14 rounded-lg mb-3 shadow-inner border border-white/10 relative overflow-hidden"
                style={{ backgroundColor: c.hex }}
              >
                <div className="absolute inset-0 bg-white/0 group-hover:bg-white/10 transition-colors flex items-center justify-center">
                  {isCopied ? (
                    <span className="bg-black/80 text-emerald-400 p-1.5 rounded-full text-xs shadow-md">
                      <Check className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <span className="opacity-0 group-hover:opacity-100 bg-black/80 text-white p-1.5 rounded-full text-xs transition-opacity shadow-md">
                      <Copy className="w-3.5 h-3.5" />
                    </span>
                  )}
                </div>
              </div>
              <div className="flex items-baseline justify-between">
                <span className="font-semibold text-xs text-white">{c.name}</span>
                <span className="font-mono text-[11px] text-[#8AB4F8] font-medium">{c.hex}</span>
              </div>
              <p className="text-[11px] text-white/40 line-clamp-2 mt-1 leading-tight">
                {c.description}
              </p>
            </button>
          );
        })}
      </div>
    </div>
  );
};
