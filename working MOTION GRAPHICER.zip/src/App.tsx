import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ViewportHarness, ViewportHarnessRef } from './components/ViewportHarness';
import { TimelineControls } from './components/TimelineControls';
import { BrandPaletteViewer } from './components/BrandPaletteViewer';
import { ExportPanel } from './components/ExportPanel';
import { CodeInspector } from './components/CodeInspector';
import { AspectRatioType, RenderState, ExportSettings, ExportResolution, AlphaPreviewMode } from './types';
import * as htmlToImage from 'html-to-image';
import JSZip from 'jszip';
import { Muxer as Mp4Muxer, ArrayBufferTarget as Mp4ArrayBufferTarget } from 'mp4-muxer';
import { Muxer as WebmMuxer, ArrayBufferTarget as WebmArrayBufferTarget } from 'webm-muxer';
import { QuickTimeMovMuxer } from './utils/movMuxer';
import {
  Sparkles,
  Film,
  Code2,
  CheckCircle2,
  ShieldCheck,
  Zap,
  SlidersHorizontal,
  Play,
  RotateCcw,
} from 'lucide-react';
import canvasHtmlRaw from '../canvas.html?raw';

export default function App() {
  const [renderState, setRenderState] = useState<RenderState>({
    currentFrame: 0,
    totalFrames: 840,
    fps: 60,
    isPlaying: false,
    playbackSpeed: 1.0,
    isLooping: true,
    aspectRatio: '1:1',
    alphaMode: 'studio',
    isReady: false,
  });

  const [activeTab, setActiveTab] = useState<'studio' | 'export' | 'palette' | 'code'>('studio');
  const [customHtml, setCustomHtml] = useState<string | null>(null);
  const [lowEndSafe, setLowEndSafe] = useState<boolean>(true);

  const harnessRef = useRef<ViewportHarnessRef>(null);
  const isSeekingRef = useRef<boolean>(false);
  // Cache the embedded @font-face CSS once per export run instead of
  // re-fetching every Google Font file from the network on every single frame.
  const fontEmbedCssRef = useRef<string | null>(null);

  // Pre-computes and caches font embedding once before an export run starts.
  const primeFontEmbedCache = async (): Promise<void> => {
    const iframeEl = harnessRef.current?.getIframeElement();
    const rootNode = iframeEl?.contentDocument?.getElementById('static-canvas-root');
    if (!rootNode) return;
    try {
      fontEmbedCssRef.current = await htmlToImage.getFontEmbedCSS(rootNode as HTMLElement);
    } catch (err) {
      console.warn('Font embed pre-cache failed, falling back to per-frame embedding:', err);
      fontEmbedCssRef.current = null;
    }
  };

  // Frame seek handler (called on user drag / click)
  const handleSeekFrame = useCallback((frame: number) => {
    const clamped = Math.max(0, Math.min(renderState.totalFrames - 1, frame));
    setRenderState((prev) => ({ ...prev, currentFrame: clamped }));
    harnessRef.current?.seekTo(clamped);
  }, [renderState.totalFrames]);

  // Frame update handler from native GSAP timeline inside iframe
  const handleFrameUpdate = useCallback((frame: number) => {
    if (!isSeekingRef.current) {
      setRenderState((prev) => {
        if (prev.currentFrame === frame) return prev;
        return { ...prev, currentFrame: frame };
      });
    }
  }, []);

  // Play / Pause toggle
  const handleTogglePlay = useCallback(() => {
    setRenderState((prev) => {
      const nextPlaying = !prev.isPlaying;
      if (nextPlaying) {
        harnessRef.current?.playNative(prev.playbackSpeed);
      } else {
        harnessRef.current?.pauseNative();
      }
      return { ...prev, isPlaying: nextPlaying };
    });
  }, []);

  // Speed change
  const handleChangeSpeed = useCallback((speed: number) => {
    setRenderState((prev) => {
      if (prev.isPlaying) {
        harnessRef.current?.playNative(speed);
      }
      return { ...prev, playbackSpeed: speed };
    });
  }, []);

  // Loop toggle
  const handleToggleLoop = useCallback(() => {
    setRenderState((prev) => {
      const nextLoop = !prev.isLooping;
      harnessRef.current?.setLooping(nextLoop);
      return { ...prev, isLooping: nextLoop };
    });
  }, []);

  // Timeline completion callback (when looping is disabled)
  const handleTimelineComplete = useCallback(() => {
    setRenderState((prev) => {
      if (!prev.isLooping) {
        return { ...prev, isPlaying: false, currentFrame: prev.totalFrames };
      }
      return prev;
    });
  }, []);

  // Harness readiness callback
  const handleHarnessReady = useCallback((total: number) => {
    setRenderState((prev) => {
      harnessRef.current?.setLooping(prev.isLooping);
      return {
        ...prev,
        totalFrames: total,
        isReady: true,
      };
    });
    harnessRef.current?.seekTo(0);
  }, []);

  // Keyboard navigation for precision frame stepping
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) return;

      if (e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        handleSeekFrame(renderState.currentFrame - (e.shiftKey ? 10 : 1));
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        handleSeekFrame(renderState.currentFrame + (e.shiftKey ? 10 : 1));
      } else if (e.code === 'Home') {
        e.preventDefault();
        handleSeekFrame(0);
      } else if (e.code === 'End') {
        e.preventDefault();
        handleSeekFrame(renderState.totalFrames - 1);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [renderState.currentFrame, renderState.totalFrames, handleSeekFrame, handleTogglePlay]);

  // High-Fidelity True DOM Frame Rasterizer (Captures live HTML/CSS/SVG elements directly with Alpha transparency)
  const captureDOMFrameToCanvas = async (
    frame: number,
    targetCanvas: HTMLCanvasElement,
    resW: number,
    resH: number,
    transparent = false
  ): Promise<void> => {
    const iframeEl = harnessRef.current?.getIframeElement();
    if (!iframeEl || !iframeEl.contentDocument || !iframeEl.contentWindow) return;
    const win = iframeEl.contentWindow as any;

    // Toggle transparency in canvas script
    if (typeof win.setTransparencyMode === 'function') {
      win.setTransparencyMode(transparent);
    }

    // 1. Seek timeline precisely to requested frame
    if (typeof win.seekFrame === 'function') {
      win.seekFrame(frame);
    }

    // Micro-delay for GSAP DOM inline styles & filters to update
    await new Promise((r) => requestAnimationFrame(r));

    const ctx = targetCanvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    const rootNode =
      iframeEl.contentDocument.getElementById('static-canvas-root') ||
      iframeEl.contentDocument.querySelector('.canvas-container');

    if (rootNode) {
      try {
        const stageDim = Math.min(resW, resH);
        const pixelRatio = stageDim / 720;

        const useCachedFonts = !!fontEmbedCssRef.current;
        const domCanvas = await htmlToImage.toCanvas(rootNode as HTMLElement, {
          width: 720,
          height: 720,
          pixelRatio: pixelRatio,
          backgroundColor: transparent ? undefined : '#080c14',
          skipFonts: useCachedFonts,
          fontEmbedCSS: useCachedFonts ? fontEmbedCssRef.current! : undefined,
          cacheBust: false,
          style: {
            transform: 'scale(1)',
            transformOrigin: 'center center',
            margin: '0',
            borderRadius: '0',
            background: transparent ? 'transparent' : '#080c14',
          },
        });

        ctx.clearRect(0, 0, resW, resH);

        if (resW === resH) {
          ctx.drawImage(domCanvas, 0, 0, resW, resH);
        } else {
          // If non-transparent, fill deep blue backdrop for non-1:1 aspect ratios
          if (!transparent) {
            const bgGrad = ctx.createRadialGradient(
              resW / 2,
              resH * 0.32,
              0,
              resW / 2,
              resH * 0.32,
              Math.max(resW, resH) * 0.85
            );
            bgGrad.addColorStop(0, '#2067d4');
            bgGrad.addColorStop(0.48, '#174EA6');
            bgGrad.addColorStop(0.82, '#0b275b');
            bgGrad.addColorStop(1.0, '#061635');
            ctx.fillStyle = bgGrad;
            ctx.fillRect(0, 0, resW, resH);
          }

          const offsetX = (resW - stageDim) / 2;
          const offsetY = (resH - stageDim) / 2;
          ctx.drawImage(domCanvas, offsetX, offsetY, stageDim, stageDim);
        }
        return;
      } catch (err) {
        console.warn('DOM htmlToImage capture exception, fallback to canvas renderer:', err);
      }
    }

    // Fallback if DOM capture throws
    if (typeof win.renderFrameToCanvas === 'function') {
      win.renderFrameToCanvas(frame, targetCanvas, resW, resH);
    }
  };

  // Video Export (Hardware-Accelerated WebCodecs, MP4/WebM Muxer, and QuickTime MOV Muxer with full Alpha)
  const handleRecordDeterministicExport = async (
    settings: ExportSettings,
    onProgress: (pct: number, currentFrame: number, estSecRemaining: number) => void,
    signal?: { cancelled: boolean }
  ): Promise<Blob | null> => {
    const iframeEl = harnessRef.current?.getIframeElement();
    const win = iframeEl?.contentWindow as any;

    if (!win) {
      alert('Canvas viewport engine is not ready for recording');
      return null;
    }

    // Pause live playback during export
    if (renderState.isPlaying) {
      setRenderState((prev) => ({ ...prev, isPlaying: false }));
      harnessRef.current?.pauseNative();
    }

    // Warm font cache once so htmlToImage does not fetch fonts over network on every frame
    fontEmbedCssRef.current = null;
    await primeFontEmbedCache();

    const [resW, resH] = settings.resolution.split('x').map((v) => parseInt(v, 10));

    // Create offscreen recording canvas with true alpha support
    const recCanvas = document.createElement('canvas');
    recCanvas.width = resW;
    recCanvas.height = resH;
    const ctx = recCanvas.getContext('2d', { alpha: true });

    if (!ctx) {
      alert('Could not initialize export graphics context');
      return null;
    }

    const totalFrames = settings.endFrame - settings.startFrame + 1;
    const startTime = performance.now();
    const isMov = settings.format.startsWith('mov-') || settings.format === 'raw-rgba';
    const isMp4 = settings.format === 'mp4-h264';
    const isWebm = settings.format.startsWith('webm-');

    // --- CASE 1: QUICKTIME (.MOV) WITH 32-BIT ALPHA (ProRes 4444 / qtrle / CineForm / Raw RGBA) ---
    if (isMov) {
      const fourcc =
        settings.format === 'mov-qtrle'
          ? 'qtrle'
          : settings.format === 'raw-rgba'
          ? 'raw '
          : 'png ';

      const movMuxer = new QuickTimeMovMuxer({
        width: resW,
        height: resH,
        fps: settings.fps,
        fourcc: fourcc as any,
      });

      for (let f = settings.startFrame; f <= settings.endFrame; f++) {
        if (signal?.cancelled) return null;

        await captureDOMFrameToCanvas(f, recCanvas, resW, resH, settings.transparentBackground);

        // Convert frame canvas to PNG Uint8Array with alpha transparency
        const blob: Blob | null = await new Promise((resolve) => {
          recCanvas.toBlob((b) => resolve(b), 'image/png');
        });

        if (blob) {
          const arrayBuffer = await blob.arrayBuffer();
          movMuxer.addFrame(new Uint8Array(arrayBuffer));
        }

        const frameIdx = f - settings.startFrame;
        const pct = Math.round(((frameIdx + 1) / totalFrames) * 100);
        const elapsed = (performance.now() - startTime) / 1000;
        const done = frameIdx + 1;
        const remaining = Math.max(0, Math.round((elapsed / done) * (settings.endFrame - f)));
        onProgress(pct, f, remaining);

        // Low-End PC Memory & CPU Yielding Protection
        if (settings.safeMode || frameIdx % 6 === 0) {
          await new Promise((r) => setTimeout(r, settings.safeMode ? 10 : 0));
        }
      }

      if (signal?.cancelled) return null;
      return movMuxer.finalize();
    }

    // --- CASE 2: HARDWARE-ACCELERATED WEBCODECS / MP4 / WEBM ---
    const frameDurationMicros = Math.round(1_000_000 / settings.fps);

    if (typeof VideoEncoder !== 'undefined' && typeof VideoFrame !== 'undefined') {
      try {
        if (isMp4) {
          const target = new Mp4ArrayBufferTarget();
          const muxer = new Mp4Muxer({
            target,
            video: {
              codec: 'avc',
              width: resW,
              height: resH,
            },
            fastStart: 'in-memory',
            firstTimestampBehavior: 'offset',
          });

          let chosenCodec = 'avc1.420034';
          const candidateCodecs = ['avc1.4d0034', 'avc1.420034', 'avc1.640034', 'avc1.42E01E'];
          for (const c of candidateCodecs) {
            try {
              const support = await VideoEncoder.isConfigSupported({
                codec: c,
                width: resW,
                height: resH,
                bitrate: settings.bitrateMbps * 1_000_000,
                framerate: settings.fps,
              });
              if (support.supported) {
                chosenCodec = c;
                break;
              }
            } catch {}
          }

          const encoder = new VideoEncoder({
            output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
            error: (e) => console.error('WebCodecs H.264 encoder error:', e),
          });

          encoder.configure({
            codec: chosenCodec,
            width: resW,
            height: resH,
            bitrate: settings.bitrateMbps * 1_000_000,
            framerate: settings.fps,
          });

          for (let f = settings.startFrame; f <= settings.endFrame; f++) {
            if (signal?.cancelled) {
              try { encoder.close(); } catch {}
              return null;
            }

            await captureDOMFrameToCanvas(f, recCanvas, resW, resH, settings.transparentBackground);

            const frameIdx = f - settings.startFrame;
            const timestampMicros = Math.round((frameIdx / settings.fps) * 1_000_000);

            const videoFrame = new VideoFrame(recCanvas, {
              timestamp: timestampMicros,
              duration: frameDurationMicros,
            });

            const keyFrame = frameIdx % (settings.fps * 2) === 0;
            encoder.encode(videoFrame, { keyFrame });
            videoFrame.close();

            const pct = Math.round(((frameIdx + 1) / totalFrames) * 100);
            const elapsed = (performance.now() - startTime) / 1000;
            const done = frameIdx + 1;
            const remaining = Math.max(0, Math.round((elapsed / done) * (settings.endFrame - f)));
            onProgress(pct, f, remaining);

            if (settings.safeMode || frameIdx % 10 === 0) {
              await new Promise((r) => setTimeout(r, settings.safeMode ? 8 : 0));
            }
          }

          await encoder.flush();
          try { encoder.close(); } catch {}
          muxer.finalize();

          return new Blob([target.buffer], { type: 'video/mp4' });
        } else if (isWebm) {
          // WebM VP9/VP8 Alpha export via webm-muxer
          const isVp9 = settings.format.includes('vp9');
          const target = new WebmArrayBufferTarget();
          const muxer = new WebmMuxer({
            target,
            video: {
              codec: isVp9 ? 'V_VP9' : 'V_VP8',
              width: resW,
              height: resH,
              frameRate: settings.fps,
              alpha: settings.transparentBackground,
            },
            firstTimestampBehavior: 'offset',
          });

          let chosenCodec = isVp9 ? 'vp09.00.10.08' : 'vp8';
          if (isVp9) {
            try {
              const support = await VideoEncoder.isConfigSupported({
                codec: 'vp09.00.10.08',
                width: resW,
                height: resH,
                bitrate: settings.bitrateMbps * 1_000_000,
                framerate: settings.fps,
                alpha: settings.transparentBackground ? 'keep' : 'discard',
              } as any);
              if (!support.supported) {
                chosenCodec = 'vp8';
              }
            } catch {
              chosenCodec = 'vp8';
            }
          }

          const encoder = new VideoEncoder({
            output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
            error: (e) => console.error('WebCodecs WebM encoder error:', e),
          });

          encoder.configure({
            codec: chosenCodec,
            width: resW,
            height: resH,
            bitrate: settings.bitrateMbps * 1_000_000,
            framerate: settings.fps,
            alpha: settings.transparentBackground ? 'keep' : 'discard',
          } as any);

          for (let f = settings.startFrame; f <= settings.endFrame; f++) {
            if (signal?.cancelled) {
              try { encoder.close(); } catch {}
              return null;
            }

            await captureDOMFrameToCanvas(f, recCanvas, resW, resH, settings.transparentBackground);

            const frameIdx = f - settings.startFrame;
            const timestampMicros = Math.round((frameIdx / settings.fps) * 1_000_000);

            const videoFrame = new VideoFrame(recCanvas, {
              timestamp: timestampMicros,
              duration: frameDurationMicros,
              alpha: settings.transparentBackground ? 'keep' : 'discard',
            } as any);

            const keyFrame = frameIdx % (settings.fps * 2) === 0;
            encoder.encode(videoFrame, { keyFrame });
            videoFrame.close();

            const pct = Math.round(((frameIdx + 1) / totalFrames) * 100);
            const elapsed = (performance.now() - startTime) / 1000;
            const done = frameIdx + 1;
            const remaining = Math.max(0, Math.round((elapsed / done) * (settings.endFrame - f)));
            onProgress(pct, f, remaining);

            if (settings.safeMode || frameIdx % 10 === 0) {
              await new Promise((r) => setTimeout(r, settings.safeMode ? 8 : 0));
            }
          }

          await encoder.flush();
          try { encoder.close(); } catch {}
          muxer.finalize();

          return new Blob([target.buffer], { type: 'video/webm' });
        }
      } catch (webcodecsErr) {
        console.warn('WebCodecs execution exception, falling back to real-time display recording:', webcodecsErr);
      }
    }

    // --- CASE 3: FALLBACK (Legacy MediaRecorder if WebCodecs is unsupported) ---
    let mimeType = 'video/webm;codecs=vp9';
    if (isMp4 && MediaRecorder.isTypeSupported('video/mp4;codecs=avc1.42E01E,mp4a.40.2')) {
      mimeType = 'video/mp4;codecs=avc1.42E01E,mp4a.40.2';
    } else if (isMp4 && MediaRecorder.isTypeSupported('video/mp4')) {
      mimeType = 'video/mp4';
    } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
      mimeType = 'video/webm;codecs=vp9';
    } else if (MediaRecorder.isTypeSupported('video/webm')) {
      mimeType = 'video/webm';
    }

    const stream = recCanvas.captureStream(settings.fps);
    const mediaRecorder = new MediaRecorder(stream, {
      mimeType,
      videoBitsPerSecond: settings.bitrateMbps * 1000000,
    });

    const chunks: Blob[] = [];
    mediaRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    return new Promise(async (resolve) => {
      mediaRecorder.onstop = () => {
        const outBlob = new Blob(chunks, { type: mimeType.split(';')[0] });
        stream.getTracks().forEach((track) => track.stop());
        resolve(outBlob);
      };

      mediaRecorder.start(100);

      const frameDelayMs = 1000 / settings.fps;
      for (let f = settings.startFrame; f <= settings.endFrame; f++) {
        if (signal?.cancelled) {
          mediaRecorder.stop();
          stream.getTracks().forEach((t) => t.stop());
          resolve(null);
          return;
        }

        const t0 = performance.now();
        await captureDOMFrameToCanvas(f, recCanvas, resW, resH, settings.transparentBackground);
        const captureTime = performance.now() - t0;

        const frameIdx = f - settings.startFrame;
        const pct = Math.round(((frameIdx + 1) / totalFrames) * 100);
        const elapsed = (performance.now() - startTime) / 1000;
        const done = frameIdx + 1;
        const remaining = Math.max(0, Math.round((elapsed / done) * (settings.endFrame - f)));
        onProgress(pct, f, remaining);

        const waitTime = Math.max(0, frameDelayMs - captureTime);
        if (waitTime > 0) {
          await new Promise((r) => setTimeout(r, waitTime));
        } else {
          await new Promise((r) => setTimeout(r, 0));
        }
      }

      setTimeout(() => {
        if (mediaRecorder.state !== 'inactive') {
          mediaRecorder.stop();
        }
      }, 200);
    });
  };

  // Compressed PNG Sequence ZIP Export
  const handleExportZipSequence = async (
    settings: ExportSettings,
    onProgress: (pct: number, currentFrame: number, estSecRemaining: number) => void,
    signal?: { cancelled: boolean }
  ): Promise<Blob | null> => {
    const iframeEl = harnessRef.current?.getIframeElement();
    const win = iframeEl?.contentWindow as any;

    if (!win) {
      alert('Canvas viewport engine is not ready for ZIP export');
      return null;
    }

    // Pause live playback during export
    if (renderState.isPlaying) {
      setRenderState((prev) => ({ ...prev, isPlaying: false }));
      harnessRef.current?.pauseNative();
    }

    // Warm font-embed cache once for this run
    fontEmbedCssRef.current = null;
    await primeFontEmbedCache();

    const [resW, resH] = settings.resolution.split('x').map((v) => parseInt(v, 10));
    const offCanvas = document.createElement('canvas');
    offCanvas.width = resW;
    offCanvas.height = resH;

    const zip = new JSZip();
    const folder = zip.folder(`frames_${resW}x${resH}`) || zip;

    const total = settings.endFrame;
    const start = settings.startFrame;
    const startTime = performance.now();

    for (let f = start; f <= total; f++) {
      if (signal?.cancelled) return null;

      // 1. Render true DOM frame directly to offscreen canvas with alpha support
      await captureDOMFrameToCanvas(f, offCanvas, resW, resH, settings.transparentBackground);

      // 2. Convert canvas to PNG blob (32-bit RGBA)
      const blob: Blob | null = await new Promise((resolve) => {
        offCanvas.toBlob((b) => resolve(b), 'image/png');
      });

      if (blob) {
        const fileName = `frame_${String(f).padStart(5, '0')}.png`;
        folder.file(fileName, blob);
      }

      // Smooth cooperative yield to avoid UI freezing
      if (settings.safeMode || f % 4 === 0) {
        await new Promise((r) => setTimeout(r, settings.safeMode ? 10 : 4));
      }

      const pct = Math.round(((f - start + 1) / (total - start + 1)) * 88); // 0-88% for capture
      const elapsed = (performance.now() - startTime) / 1000;
      const done = f - start + 1;
      const remaining = Math.round((elapsed / done) * (total - f));
      onProgress(pct, f, remaining);
    }

    if (signal?.cancelled) return null;

    // Generate compressed ZIP archive
    const zipBlob = await zip.generateAsync(
      {
        type: 'blob',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
      },
      (metadata) => {
        const zipPct = 88 + Math.round(metadata.percent * 0.12);
        onProgress(zipPct, total, 0);
      }
    );

    return zipBlob;
  };

  // High-resolution frame snapshot
  const handleCaptureSnapshot = async (res: ExportResolution, transparent = false) => {
    const iframeEl = harnessRef.current?.getIframeElement();
    const win = iframeEl?.contentWindow as any;

    if (!win) {
      window.open('/canvas.html', '_blank');
      return;
    }

    const [resW, resH] = res.split('x').map((v) => parseInt(v, 10));
    const snapCanvas = document.createElement('canvas');
    snapCanvas.width = resW;
    snapCanvas.height = resH;

    await captureDOMFrameToCanvas(renderState.currentFrame, snapCanvas, resW, resH, transparent);

    const dataUrl = snapCanvas.toDataURL('image/png');
    if (dataUrl) {
      const a = document.createElement('a');
      a.href = dataUrl;
      const alphaSuffix = transparent ? '_alpha' : '';
      a.download = `frame_${String(renderState.currentFrame).padStart(4, '0')}_${res}${alphaSuffix}.png`;
      a.click();
    }
  };

  const handleApplyCode = (newCode: string) => {
    setCustomHtml(newCode);
    setTimeout(() => {
      harnessRef.current?.reloadIframe();
    }, 100);
  };

  const handleResetCode = () => {
    setCustomHtml(null);
    setTimeout(() => {
      harnessRef.current?.reloadIframe();
    }, 100);
  };

  return (
    <div
      id="apple-studio-app-root"
      className="min-h-screen bg-[#070709] text-white flex flex-col selection:bg-[#1A73E8] selection:text-white font-sans antialiased"
    >
      {/* Top Apple Minimal Navigation Bar */}
      <header
        id="studio-apple-header"
        className="sticky top-0 z-50 border-b border-white/[0.08] bg-[#0A0A0C]/80 backdrop-blur-2xl px-4 sm:px-8 py-3.5"
      >
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Brand Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#1A73E8] to-[#174EA6] flex items-center justify-center shadow-lg shadow-blue-500/25 border border-white/20">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-semibold tracking-tight text-white">
                  Motion Studio
                </h1>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/[0.06] border border-white/[0.08] text-[#8AB4F8] font-mono">
                  720p Native Master
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono">
                  Alpha ProRes / QuickTime
                </span>
              </div>
              <p className="text-[11px] text-white/40">
                Smooth 60 FPS Playback • Transparent Video Codecs & ProRes 4444 Exporter
              </p>
            </div>
          </div>

          {/* Center Apple-Style Segmented Navigation Tabs */}
          <nav
            id="apple-segmented-nav"
            className="flex items-center bg-white/[0.04] border border-white/[0.08] rounded-xl p-1 text-xs"
          >
            <button
              id="tab-btn-studio"
              onClick={() => setActiveTab('studio')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                activeTab === 'studio'
                  ? 'bg-white/15 text-white font-semibold shadow-xs'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Preview & Timeline
            </button>

            <button
              id="tab-btn-export"
              onClick={() => setActiveTab('export')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                activeTab === 'export'
                  ? 'bg-white/15 text-white font-semibold shadow-xs'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Export Studio (Video & ZIP)
            </button>

            <button
              id="tab-btn-palette"
              onClick={() => setActiveTab('palette')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                activeTab === 'palette'
                  ? 'bg-white/15 text-white font-semibold shadow-xs'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Brand Colors
            </button>

            <button
              id="tab-btn-code"
              onClick={() => setActiveTab('code')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                activeTab === 'code'
                  ? 'bg-white/15 text-white font-semibold shadow-xs'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Code Inspector
            </button>
          </nav>

          {/* Right Spec Pills */}
          <div className="hidden md:flex items-center gap-2 text-xs font-mono">
            <span className="px-2.5 py-1 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white/70 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              720p 60 FPS
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-white/[0.04] border border-white/[0.08] text-white/70">
              14.0s (840f)
            </span>
          </div>
        </div>
      </header>

      {/* Main Workbench Body */}
      <main id="apple-studio-main" className="max-w-7xl mx-auto px-4 sm:px-8 py-6 flex-1 w-full space-y-6 relative">
        {/* Studio Preview View */}
        <div
          id="section-studio-preview"
          className={
            activeTab === 'studio'
              ? 'space-y-6 block relative'
              : 'space-y-6 absolute top-0 left-0 w-full opacity-0 pointer-events-none -z-10'
          }
          aria-hidden={activeTab !== 'studio'}
        >
          {/* Main 720p Canvas Viewport */}
          <ViewportHarness
            ref={harnessRef}
            renderState={renderState}
            onHarnessReady={handleHarnessReady}
            onFrameUpdate={handleFrameUpdate}
            onTimelineComplete={handleTimelineComplete}
            onSelectAspectRatio={(ratio) => setRenderState((prev) => ({ ...prev, aspectRatio: ratio }))}
            onSelectAlphaMode={(mode: AlphaPreviewMode) => setRenderState((prev) => ({ ...prev, alphaMode: mode }))}
            customHtml={customHtml}
            sceneSrc="/canvas.html"
            lowEndSafe={lowEndSafe}
          />

          {/* Minimalist Apple Timeline & Scrubber Bar */}
          <TimelineControls
            renderState={renderState}
            onSeekFrame={handleSeekFrame}
            onTogglePlay={handleTogglePlay}
            onToggleLoop={handleToggleLoop}
            onChangeSpeed={handleChangeSpeed}
            onReset={() => handleSeekFrame(0)}
          />

          {/* Brand Palette Summary Swatch Row */}
          <BrandPaletteViewer />
        </div>

        {/* Export Studio Tab */}
        {activeTab === 'export' && (
          <div id="section-export-studio">
            <ExportPanel
              renderState={renderState}
              onRecordDeterministicExport={handleRecordDeterministicExport}
              onExportZipSequence={handleExportZipSequence}
              onCaptureSnapshot={handleCaptureSnapshot}
            />
          </div>
        )}

        {/* Brand Palette Tab */}
        {activeTab === 'palette' && (
          <div id="section-palette-studio">
            <BrandPaletteViewer />
          </div>
        )}

        {/* Code Inspector Tab */}
        {activeTab === 'code' && (
          <div id="section-code-studio">
            <CodeInspector
              initialCode={customHtml || canvasHtmlRaw}
              onApplyCode={handleApplyCode}
              onResetCode={handleResetCode}
            />
          </div>
        )}
      </main>

      {/* Apple Studio Minimal Footer */}
      <footer
        id="studio-apple-footer"
        className="border-t border-white/[0.06] bg-[#070709] py-4 text-xs text-white/40 text-center select-none"
      >
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Motion Graphics Studio &bull; Apple ProRes 4444 & QuickTime MOV Master Edition</span>
          <span className="font-mono text-white/50 text-[11px]">
            Harness Hook: <code className="text-[#8AB4F8] bg-white/[0.06] px-1.5 py-0.5 rounded">window.renderFrameToCanvas(f, canvas, w, h)</code>
          </span>
        </div>
      </footer>
    </div>
  );
}
