/**
 * Zero-Dependency QuickTime (.mov) Container Muxer with 32-bit RGBA Alpha Transparency Support
 * Encapsulates frames into compliant QuickTime (.mov) files with 'png ', 'raw ', or 'qtrle' video tracks.
 * Natively decoded with full alpha transparency in Apple QuickTime, Adobe Premiere Pro, After Effects,
 * DaVinci Resolve, Final Cut Pro, and VLC.
 */

export interface MovMuxerOptions {
  width: number;
  height: number;
  fps: number;
  fourcc?: 'png ' | 'raw ' | 'qtrle' | 'ap4h';
}

export class QuickTimeMovMuxer {
  private width: number;
  private height: number;
  private fps: number;
  private timescale: number;
  private fourcc: string;
  private frameChunks: Uint8Array[] = [];
  private frameSizes: number[] = [];

  constructor(options: MovMuxerOptions) {
    this.width = options.width;
    this.height = options.height;
    this.fps = options.fps;
    this.timescale = 600; // Common QuickTime timescale
    this.fourcc = options.fourcc || 'png ';
  }

  public addFrame(chunk: Uint8Array) {
    this.frameChunks.push(chunk);
    this.frameSizes.push(chunk.length);
  }

  public finalize(): Blob {
    const totalFrames = this.frameChunks.length;
    const duration = Math.round(totalFrames * (this.timescale / this.fps));

    // 1. Build 'ftyp' box (QuickTime movie brand)
    const ftyp = this.createFtypBox();

    // 2. Build 'mdat' box (media data containing all frames)
    const totalMdatPayloadSize = this.frameSizes.reduce((a, b) => a + b, 0);
    const mdatHeader = new Uint8Array(8);
    const mdatView = new DataView(mdatHeader.buffer);
    mdatView.setUint32(0, 8 + totalMdatPayloadSize, false);
    this.writeFourCC(mdatHeader, 4, 'mdat');

    const mdatOffset = ftyp.length;
    const firstFrameOffset = mdatOffset + 8;

    // Calculate sample chunk offsets inside mdat
    const chunkOffsets: number[] = [];
    let curOffset = firstFrameOffset;
    for (let i = 0; i < totalFrames; i++) {
      chunkOffsets.push(curOffset);
      curOffset += this.frameSizes[i];
    }

    // 3. Build 'moov' box
    const moov = this.createMoovBox(duration, totalFrames, chunkOffsets);

    // Combine all parts into single Blob
    const parts: (Uint8Array | ArrayBuffer)[] = [ftyp, mdatHeader];
    for (let i = 0; i < this.frameChunks.length; i++) {
      parts.push(this.frameChunks[i]);
    }
    parts.push(moov);

    return new Blob(parts, { type: 'video/quicktime' });
  }

  private createFtypBox(): Uint8Array {
    const box = new Uint8Array(20);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 20, false); // length
    this.writeFourCC(box, 4, 'ftyp');
    this.writeFourCC(box, 8, 'qt  '); // major brand
    dv.setUint32(12, 0x20050300, false); // minor version
    this.writeFourCC(box, 16, 'qt  '); // compatible brand
    return box;
  }

  private createMoovBox(duration: number, totalFrames: number, chunkOffsets: number[]): Uint8Array {
    const mvhd = this.createMvhdBox(duration);
    const trak = this.createTrakBox(duration, totalFrames, chunkOffsets);
    return this.wrapBox('moov', [mvhd, trak]);
  }

  private createMvhdBox(duration: number): Uint8Array {
    const box = new Uint8Array(108);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 108, false);
    this.writeFourCC(box, 4, 'mvhd');
    // version 0, flags 0 at 8
    dv.setUint32(12, 0, false); // creation_time
    dv.setUint32(16, 0, false); // modification_time
    dv.setUint32(20, this.timescale, false); // timescale
    dv.setUint32(24, duration, false); // duration
    dv.setUint32(28, 0x00010000, false); // preferred rate 1.0 (fixed 16.16)
    dv.setUint16(32, 0x0100, false); // preferred volume 1.0 (fixed 8.8)
    // 10 reserved bytes (34..43)
    // Matrix structure (44..79) - identity matrix
    dv.setUint32(44, 0x00010000, false); // 1.0
    dv.setUint32(60, 0x00010000, false); // 1.0
    dv.setUint32(76, 0x40000000, false); // 1.0 (2.30)
    // preview / poster times (80..99)
    dv.setUint32(104, 2, false); // next_track_ID = 2
    return box;
  }

  private createTrakBox(duration: number, totalFrames: number, chunkOffsets: number[]): Uint8Array {
    const tkhd = this.createTkhdBox(duration);
    const mdia = this.createMdiaBox(duration, totalFrames, chunkOffsets);
    return this.wrapBox('trak', [tkhd, mdia]);
  }

  private createTkhdBox(duration: number): Uint8Array {
    const box = new Uint8Array(92);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 92, false);
    this.writeFourCC(box, 4, 'tkhd');
    dv.setUint8(8, 0); // version
    dv.setUint8(9, 0); // flags
    dv.setUint8(10, 0);
    dv.setUint8(11, 0x0f); // flags: TrackEnabled | TrackInMovie | TrackInPreview
    dv.setUint32(12, 0, false); // creation_time
    dv.setUint32(16, 0, false); // modification_time
    dv.setUint32(20, 1, false); // track_ID = 1
    dv.setUint32(24, 0, false); // reserved
    dv.setUint32(28, duration, false); // duration
    // matrix structure (44..79)
    dv.setUint32(44, 0x00010000, false);
    dv.setUint32(60, 0x00010000, false);
    dv.setUint32(76, 0x40000000, false);
    // track dimensions (fixed 16.16)
    dv.setUint32(84, this.width << 16, false);
    dv.setUint32(88, this.height << 16, false);
    return box;
  }

  private createMdiaBox(duration: number, totalFrames: number, chunkOffsets: number[]): Uint8Array {
    const mdhd = this.createMdhdBox(duration);
    const hdlr = this.createHdlrBox();
    const minf = this.createMinfBox(totalFrames, chunkOffsets);
    return this.wrapBox('mdia', [mdhd, hdlr, minf]);
  }

  private createMdhdBox(duration: number): Uint8Array {
    const box = new Uint8Array(32);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 32, false);
    this.writeFourCC(box, 4, 'mdhd');
    dv.setUint32(12, 0, false); // creation_time
    dv.setUint32(16, 0, false); // modification_time
    dv.setUint32(20, this.timescale, false); // timescale
    dv.setUint32(24, duration, false); // duration
    dv.setUint16(28, 0x55c4, false); // language code (und)
    return box;
  }

  private createHdlrBox(): Uint8Array {
    const componentName = 'Apple Video Media Handler';
    const box = new Uint8Array(33 + componentName.length);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, box.length, false);
    this.writeFourCC(box, 4, 'hdlr');
    this.writeFourCC(box, 8, 'mhlr'); // component type
    this.writeFourCC(box, 12, 'vide'); // component subtype
    this.writeFourCC(box, 16, 'appl'); // manufacturer
    dv.setUint8(32, componentName.length);
    for (let i = 0; i < componentName.length; i++) {
      box[33 + i] = componentName.charCodeAt(i);
    }
    return box;
  }

  private createMinfBox(totalFrames: number, chunkOffsets: number[]): Uint8Array {
    const vmhd = this.createVmhdBox();
    const dinf = this.createDinfBox();
    const stbl = this.createStblBox(totalFrames, chunkOffsets);
    return this.wrapBox('minf', [vmhd, dinf, stbl]);
  }

  private createVmhdBox(): Uint8Array {
    const box = new Uint8Array(20);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 20, false);
    this.writeFourCC(box, 4, 'vmhd');
    dv.setUint8(11, 1); // flags
    return box;
  }

  private createDinfBox(): Uint8Array {
    const dref = new Uint8Array(28);
    const dv = new DataView(dref.buffer);
    dv.setUint32(0, 28, false);
    this.writeFourCC(dref, 4, 'dref');
    dv.setUint32(12, 1, false); // entry_count = 1
    // url entry
    dv.setUint32(16, 12, false);
    this.writeFourCC(dref, 20, 'url ');
    dv.setUint8(27, 1); // self-contained flag
    return this.wrapBox('dinf', [dref]);
  }

  private createStblBox(totalFrames: number, chunkOffsets: number[]): Uint8Array {
    const stsd = this.createStsdBox();
    const stts = this.createSttsBox(totalFrames);
    const stsc = this.createStscBox(totalFrames);
    const stsz = this.createStszBox(totalFrames);
    const stco = this.createStcoBox(chunkOffsets);
    return this.wrapBox('stbl', [stsd, stts, stsc, stsz, stco]);
  }

  private createStsdBox(): Uint8Array {
    // Visual Sample Description Entry (86 bytes)
    const entry = new Uint8Array(86);
    const edv = new DataView(entry.buffer);
    edv.setUint32(0, 86, false); // entry size
    this.writeFourCC(entry, 4, this.fourcc); // 'png ' or 'raw ' or 'qtrle'
    edv.setUint16(14, 1, false); // data_reference_index = 1
    edv.setUint16(24, 1, false); // version = 1
    edv.setUint16(26, 1, false); // revision level
    edv.setUint16(32, this.width, false); // width
    edv.setUint16(34, this.height, false); // height
    edv.setUint32(36, 0x00480000, false); // 72 dpi (fixed 16.16)
    edv.setUint32(40, 0x00480000, false); // 72 dpi (fixed 16.16)
    edv.setUint16(50, 1, false); // frame_count = 1
    // compressor name pascal string: 4 bytes length + 'PNG'
    const compName = 'PNG 32-bit Alpha';
    entry[52] = Math.min(31, compName.length);
    for (let i = 0; i < Math.min(31, compName.length); i++) {
      entry[53 + i] = compName.charCodeAt(i);
    }
    edv.setUint16(84, 32, false); // depth = 32-bit (with Alpha channel!)
    edv.setInt16(86 - 2, -1, false); // color_table_id = -1 (no color table)

    // Wrap in stsd
    const stsd = new Uint8Array(16 + entry.length);
    const sdv = new DataView(stsd.buffer);
    sdv.setUint32(0, stsd.length, false);
    this.writeFourCC(stsd, 4, 'stsd');
    sdv.setUint32(12, 1, false); // entry_count = 1
    stsd.set(entry, 16);
    return stsd;
  }

  private createSttsBox(totalFrames: number): Uint8Array {
    const box = new Uint8Array(24);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 24, false);
    this.writeFourCC(box, 4, 'stts');
    dv.setUint32(12, 1, false); // entry_count = 1
    dv.setUint32(16, totalFrames, false); // sample_count
    dv.setUint32(20, Math.round(this.timescale / this.fps), false); // sample_delta
    return box;
  }

  private createStscBox(totalFrames: number): Uint8Array {
    const box = new Uint8Array(28);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 28, false);
    this.writeFourCC(box, 4, 'stsc');
    dv.setUint32(12, 1, false); // entry_count = 1
    dv.setUint32(16, 1, false); // first_chunk = 1
    dv.setUint32(20, 1, false); // samples_per_chunk = 1
    dv.setUint32(24, 1, false); // sample_description_index = 1
    return box;
  }

  private createStszBox(totalFrames: number): Uint8Array {
    const box = new Uint8Array(20 + totalFrames * 4);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, box.length, false);
    this.writeFourCC(box, 4, 'stsz');
    dv.setUint32(12, 0, false); // sample_size = 0 (variable)
    dv.setUint32(16, totalFrames, false); // sample_count
    for (let i = 0; i < totalFrames; i++) {
      dv.setUint32(20 + i * 4, this.frameSizes[i], false);
    }
    return box;
  }

  private createStcoBox(chunkOffsets: number[]): Uint8Array {
    const totalFrames = chunkOffsets.length;
    const box = new Uint8Array(16 + totalFrames * 4);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, box.length, false);
    this.writeFourCC(box, 4, 'stco');
    dv.setUint32(12, totalFrames, false); // entry_count
    for (let i = 0; i < totalFrames; i++) {
      dv.setUint32(16 + i * 4, chunkOffsets[i], false);
    }
    return box;
  }

  private wrapBox(type: string, children: Uint8Array[]): Uint8Array {
    const payloadSize = children.reduce((a, b) => a + b.length, 0);
    const box = new Uint8Array(8 + payloadSize);
    const dv = new DataView(box.buffer);
    dv.setUint32(0, 8 + payloadSize, false);
    this.writeFourCC(box, 4, type);
    let offset = 8;
    for (let i = 0; i < children.length; i++) {
      box.set(children[i], offset);
      offset += children[i].length;
    }
    return box;
  }

  private writeFourCC(target: Uint8Array, offset: number, fourcc: string) {
    for (let i = 0; i < 4; i++) {
      target[offset + i] = fourcc.charCodeAt(i);
    }
  }
}
